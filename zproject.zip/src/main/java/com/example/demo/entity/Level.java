package com.example.demo.entity;

public enum Level {
	BRONZE, SILVER, GOLD;
}
